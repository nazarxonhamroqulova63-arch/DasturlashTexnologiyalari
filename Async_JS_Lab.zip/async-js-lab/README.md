# Asinxron JavaScript laboratoriya ishi

**Talab:** Node.js 18 yoki undan yangi versiya. Tashqi kutubxonalar ishlatilmagan.

## Ishga tushirish
Terminalda loyiha ildiz papkasiga o'ting:
```bash
node partA/a1-event-loop.js
node partA/a2-callbacks.js
node partA/a3-parallel.js
node partB/promiseApi.js
node partB/b2-chaining.js
node partB/b3-combinators.js
node partC/c1-async-await.js
node partC/c2-seq-vs-parallel.js
node partC/c3-retry.js
node partD/report.js
```
`fakeApi.js` laboratoriya topshirig'idagi simulyatsiya serveri bo'lib, o'zgartirilmagan.

## Loyiha tarkibi
- `partA/` — event loop va callback topshiriqlari.
- `partB/` — promisify, Promise zanjiri va kombinatorlar.
- `partC/` — async/await, ketma-ket/parallel yuklash va retry.
- `partD/report.js` — mijozlar buyurtmalari hisoboti.
- `report.pdf` — hisobot savollariga javoblar.

Eslatma: `fakeApi.js` tasodifiy kechikish va xatolarni simulyatsiya qiladi. Shu sababli vaqt va ayrim natijalar har ishga tushirishda farq qilishi mumkin.
