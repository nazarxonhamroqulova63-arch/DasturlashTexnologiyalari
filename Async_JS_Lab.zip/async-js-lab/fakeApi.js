// Berilgan simulyatsiya serveri. O'ZGARTIRMANG.
const users = {
  1: { id: 1, name: 'Aziza' },
  2: { id: 2, name: 'Bekzod' },
  3: { id: 3, name: 'Dilnoza' },
};

const orders = {
  1: [{ id: 101, productId: 11 }, { id: 102, productId: 12 }],
  2: [{ id: 201, productId: 13 }],
  3: [],
};

const products = {
  11: { id: 11, title: 'Noutbuk', price: 9500000 },
  12: { id: 12, title: 'Sichqoncha', price: 150000 },
  13: { id: 13, title: 'Monitor', price: 2800000 },
};

function randomDelay() {
  return 100 + Math.floor(Math.random() * 400);
}
function respond(value, errorMessage, callback) {
  setTimeout(() => {
    if (value === undefined) callback(new Error(errorMessage));
    else callback(null, value);
  }, randomDelay());
}
function getUser(id, callback) {
  respond(users[id], `${id}-foydalanuvchi topilmadi`, callback);
}
function getOrders(userId, callback) {
  respond(orders[userId], `${userId}-foydalanuvchida buyurtma yo'q`, callback);
}
function getProduct(productId, callback) {
  respond(products[productId], `${productId}-mahsulot topilmadi`, callback);
}
// Ishonchsiz xizmat: taxminan 60% hollarda xato beradi.
function getExchangeRate(callback) {
  setTimeout(() => {
    if (Math.random() < 0.6) callback(new Error('503 Service Unavailable'));
    else callback(null, { usdToUzs: 12800 });
  }, randomDelay());
}
module.exports = { getUser, getOrders, getProduct, getExchangeRate };
