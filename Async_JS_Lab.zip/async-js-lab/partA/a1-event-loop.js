console.log('1: boshlanish');
setTimeout(() => console.log('2: timeout 0 ms'), 0);
Promise.resolve().then(() => console.log('3: promise then'));
queueMicrotask(() => console.log('4: queueMicrotask'));
setTimeout(() => console.log('5: timeout 10 ms'), 10);
(async () => {
  console.log('6: async funksiya ichida');
  await null;
  console.log('7: await dan keyin');
})();
console.log('8: tugash');
// Qo'shimcha: bu microtask navbatiga qo'shiladi va 3, 4, 7 dan keyin ishlaydi.
Promise.resolve().then(() => setTimeout(() => console.log('9: then ichidagi timeout'), 0));
