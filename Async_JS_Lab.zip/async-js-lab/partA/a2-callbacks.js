const api = require('../fakeApi');

function printFirstOrderProduct(userId, done) {
  let called = false;
  const finish = (err, value) => {
    if (called) return;
    called = true;
    done(err, value);
  };

  api.getUser(userId, (err, user) => {
    if (err) return finish(err);
    api.getOrders(user.id, (ordersErr, orders) => {
      if (ordersErr) return finish(ordersErr);
      if (!orders || orders.length === 0) {
        return finish(new Error("Foydalanuvchida buyurtma yo'q"));
      }
      api.getProduct(orders[0].productId, (productErr, product) => {
        if (productErr) return finish(productErr);
        finish(null, `${user.name} birinchi buyurtmasi: ${product.title} (${product.price} so'm)`);
      });
    });
  });
}

function show(err, text) {
  console.log(err ? 'Xato: ' + err.message : text);
}
printFirstOrderProduct(1, show);
printFirstOrderProduct(3, show);
printFirstOrderProduct(99, show);
