const api = require('../fakeApi');

function parallelCallbacks(tasks, done) {
  if (tasks.length === 0) return done(null, []);
  const results = new Array(tasks.length);
  let finishedCount = 0;
  let doneCalled = false;

  tasks.forEach((task, index) => {
    try {
      task((err, value) => {
        if (doneCalled) return;
        if (err) {
          doneCalled = true;
          return done(err);
        }
        results[index] = value;
        finishedCount++;
        if (finishedCount === tasks.length) {
          doneCalled = true;
          done(null, results);
        }
      });
    } catch (err) {
      if (!doneCalled) {
        doneCalled = true;
        done(err);
      }
    }
  });
}

const start = Date.now();
parallelCallbacks(
  [
    (cb) => api.getUser(1, cb),
    (cb) => api.getUser(2, cb),
    (cb) => api.getProduct(11, cb),
  ],
  (err, results) => {
    if (err) return console.log('Xato:', err.message);
    console.log('Muvaffaqiyatli parallel natija:', results);
    console.log('Sarflangan vaqt:', Date.now() - start, 'ms');
  }
);

parallelCallbacks([(cb) => api.getUser(99, cb), (cb) => api.getUser(1, cb)],
  (err, results) => console.log('Xato testi:', err ? err.message : results));
