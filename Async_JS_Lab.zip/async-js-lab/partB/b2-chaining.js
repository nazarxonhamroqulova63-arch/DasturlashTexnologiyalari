const { getUserP, getOrdersP, getProductP } = require('./promiseApi');

function firstOrderProduct(userId) {
  let userName;
  return getUserP(userId)
    .then((user) => {
      userName = user.name;
      return getOrdersP(user.id);
    })
    .then((orders) => {
      if (!orders || orders.length === 0) throw new Error("Foydalanuvchida buyurtma yo'q");
      return getProductP(orders[0].productId);
    })
    .then((product) => `${userName} birinchi buyurtmasi: ${product.title} (${product.price} so'm)`);
}

[1, 3, 99].forEach((id) => {
  firstOrderProduct(id)
    .then((text) => console.log(text))
    .catch((err) => console.log('Xato:', err.message))
    .finally(() => console.log('--- tugadi:', id));
});
