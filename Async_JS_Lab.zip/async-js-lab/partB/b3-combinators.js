const { getUserP } = require('./promiseApi');

function withTimeout(promise, ms) {
  let timer;
  const timeout = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`Timeout after ${ms} ms`)), ms);
  });
  return Promise.race([promise, timeout]).finally(() => clearTimeout(timer));
}

function myPromiseAll(promises) {
  return new Promise((resolve, reject) => {
    const list = Array.from(promises);
    if (list.length === 0) return resolve([]);
    const results = new Array(list.length);
    let completed = 0;
    list.forEach((p, index) => {
      Promise.resolve(p).then((value) => {
        results[index] = value;
        completed++;
        if (completed === list.length) resolve(results);
      }, reject);
    });
  });
}

async function main() {
  try {
    const users = await Promise.all([1, 2, 3].map((id) => getUserP(id)));
    console.log('all:', users.map((u) => u.name));
  } catch (e) { console.log('all xato:', e.message); }

  const settled = await Promise.allSettled([1, 99, 2].map((id) => getUserP(id)));
  settled.forEach((item, i) => {
    console.log('allSettled', [1, 99, 2][i],
      item.status === 'fulfilled' ? item.value.name : item.reason.message);
  });

  const timed = await Promise.allSettled(Array.from({ length: 5 }, () => withTimeout(getUserP(1), 300)));
  timed.forEach((x, i) => console.log(`timeout testi ${i + 1}:`,
    x.status === 'fulfilled' ? x.value.name : x.reason.message));

  const inputs = [1, 2, 3].map((id) => getUserP(id));
  const [mine, native] = await Promise.all([myPromiseAll(inputs), Promise.all([1, 2, 3].map(id => getUserP(id)))]);
  console.log('myPromiseAll:', mine.map(u => u.name));
  console.log('Promise.all bilan bir xil tartib:', native.map(u => u.name));
}
main().catch(err => console.error(err));
module.exports = { withTimeout, myPromiseAll };
