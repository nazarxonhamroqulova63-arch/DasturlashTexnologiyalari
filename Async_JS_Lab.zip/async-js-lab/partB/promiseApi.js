const api = require('../fakeApi');

function promisify(fn) {
  return function (...args) {
    return new Promise((resolve, reject) => {
      fn(...args, (err, value) => {
        if (err) reject(err);
        else resolve(value);
      });
    });
  };
}

const getUserP = promisify(api.getUser);
const getOrdersP = promisify(api.getOrders);
const getProductP = promisify(api.getProduct);
const getExchangeRateP = promisify(api.getExchangeRate);

module.exports = { promisify, getUserP, getOrdersP, getProductP, getExchangeRateP };

if (require.main === module) {
  getUserP(1).then((u) => console.log('OK:', u.name));
  getUserP(99).catch((e) => console.log('Kutilgan xato:', e.message));
}
