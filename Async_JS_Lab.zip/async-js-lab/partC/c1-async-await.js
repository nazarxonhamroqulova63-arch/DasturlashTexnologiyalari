const { getUserP, getOrdersP, getProductP } = require('../partB/promiseApi');

async function firstOrderProduct(userId) {
  const user = await getUserP(userId);
  const orders = await getOrdersP(user.id);
  if (!orders || orders.length === 0) throw new Error("Foydalanuvchida buyurtma yo'q");
  const product = await getProductP(orders[0].productId);
  return `${user.name} birinchi buyurtmasi: ${product.title} (${product.price} so'm)`;
}

async function main() {
  for (const id of [1, 3, 99]) {
    try {
      console.log(await firstOrderProduct(id));
    } catch (err) {
      console.log('Xato:', err.message);
    } finally {
      console.log('--- foydalanuvchi bilan ish tugadi:', id);
    }
  }
}
main();
module.exports = { firstOrderProduct };
