const { getProductP } = require('../partB/promiseApi');
const productIds = [11, 12, 13, 11, 12];

async function loadSequential(ids) {
  const result = [];
  for (const id of ids) result.push(await getProductP(id));
  return result;
}
async function loadParallel(ids) {
  return Promise.all(ids.map((id) => getProductP(id)));
}
async function loadWithForEach(ids) {
  const result = [];
  ids.forEach(async (id) => { result.push(await getProductP(id)); });
  return result; // Odatda bo'sh massiv: forEach callbacklarini kutmaydi.
}
async function main() {
  console.time('ketma-ket');
  const sequential = await loadSequential(productIds);
  console.timeEnd('ketma-ket');
  console.time('parallel');
  const parallel = await loadParallel(productIds);
  console.timeEnd('parallel');
  console.log('Yuklanganlar:', sequential.length, parallel.length);
  const early = await loadWithForEach(productIds);
  console.log('forEach qaytargan massiv uzunligi:', early.length);
  await new Promise(resolve => setTimeout(resolve, 600));
}
main();
module.exports = { loadSequential, loadParallel, loadWithForEach };
