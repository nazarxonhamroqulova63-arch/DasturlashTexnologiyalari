const { getExchangeRateP } = require('../partB/promiseApi');

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
async function retry(fn, { retries = 3, baseDelayMs = 100 } = {}) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      return await fn();
    } catch (err) {
      if (attempt === retries) throw err;
      const delay = baseDelayMs * 2 ** attempt;
      console.log(`${attempt + 1}-urinish xato: ${err.message}, ${delay} ms kutilmoqda.`);
      await sleep(delay);
    }
  }
}
async function main() {
  for (let i = 0; i < 3; i++) {
    try {
      const rate = await retry(() => getExchangeRateP(), { retries: 4, baseDelayMs: 100 });
      console.log('1 USD =', rate.usdToUzs, "so'm");
    } catch (err) {
      console.log("Urinishlar to'xtatildi:", err.message);
    }
  }
}
main();
module.exports = { sleep, retry };
