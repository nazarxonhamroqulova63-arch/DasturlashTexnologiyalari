const api = require('../partB/promiseApi');
const { withTimeout } = require('../partB/b3-combinators');
const { retry } = require('../partC/c3-retry');

async function safe(promise) { return withTimeout(promise, 1000); }

async function mapLimit(items, limit, asyncFn) {
  const results = new Array(items.length);
  let nextIndex = 0;
  async function worker() {
    while (true) {
      const i = nextIndex++;
      if (i >= items.length) return;
      results[i] = await asyncFn(items[i]);
    }
  }
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, () => worker()));
  return results;
}

async function buildUserReport(userId, usdToUzs) {
  const user = await safe(api.getUserP(userId));
  const orders = await safe(api.getOrdersP(user.id));
  const products = await Promise.all(orders.map(order => safe(api.getProductP(order.productId))));
  const totalSom = products.reduce((sum, product) => sum + product.price, 0);
  return {
    name: user.name,
    orders: orders.length,
    totalSom,
    totalUsd: Number((totalSom / usdToUzs).toFixed(2))
  };
}

async function main() {
  let usdToUzs;
  try {
    const rate = await retry(() => safe(api.getExchangeRateP()), { retries: 5, baseDelayMs: 100 });
    usdToUzs = rate.usdToUzs;
  } catch (err) {
    console.error('Valyuta kursini olib bo‘lmadi:', err.message);
    return;
  }

  const userIds = [1, 2, 3, 4, 5];
  const rows = await mapLimit(userIds, 2, async (id) => {
    try {
      return await buildUserReport(id, usdToUzs);
    } catch (err) {
      return { name: `foydalanuvchi ${id}`, orders: 'XATO: ' + err.message, totalSom: '-', totalUsd: '-' };
    }
  });
  console.table(rows);
}
if (require.main === module) main().catch(console.error);
module.exports = { mapLimit, buildUserReport };
